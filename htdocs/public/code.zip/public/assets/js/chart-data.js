// Get context with jQuery - using jQuery's .get() method.
var ctx = document.getElementById("myChart").getContext("2d");
// This will get the first returned node in the jQuery collection.

var xmlhttp = new XMLHttpRequest();
var url = "http://nbp-backend.mybluemix.net/api/revenues";
var out="";
xmlhttp.onreadystatechange = function() {
    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
        var myArr = JSON.parse(xmlhttp.responseText);
        myFunction(myArr);
    }
};
xmlhttp.open("GET", url, true);
xmlhttp.send();
function myFunction(arr) {
    var i;
    for(i = 0; i < arr.length; i++) {
        out += arr[i].price;
        console.log(arr[i].price);
    }
    // document.getElementById("id01").innerHTML = out;
}
console.log(out);

var data = {
    labels: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
    datasets: [
    {
        label: "My First dataset",
        fillColor: "rgba(220,220,220,0.2)",
        strokeColor: "rgba(220,220,220,1)",
        pointColor: "rgba(220,220,220,1)",
        pointStrokeColor: "#000",
        pointHighlightFill: "#000",
        pointHighlightStroke: "rgba(220,220,220,1)",
        data: [5000, 5500, 6000, 81, 56, 55, 40]
    }
    ]
};
var myLineChart = new Chart(ctx).Line(data);
// myLineChart.defaults.global.responsive = true;