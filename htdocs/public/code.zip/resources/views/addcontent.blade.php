@include('layouts/header');
<body>
    <div id="wrapper">
        @include('layouts/navbar');
        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Add Content
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href=<?php echo url('/dashboard'); ?>>Dashboard</a>
                            </li>
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href=<?php echo url('/services'); ?>>Services Management</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-edit"></i> Add Content
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="col-lg-12">
                        <form id="add-services" method="post" role="form" enctype='application/json'>
                            <div class="form-group">
                                <label>Konten</label>
                                <textarea class="form-control" name="konten" placeholder=""></textarea>
                            </div>
                            {{ csrf_field() }}
                            <button type="submit" name="submit" class="btn btn-default">Submit Button</button>
                            <button type="reset" class="btn btn-default">Reset Button</button>
                        </form>
                    </div>
                </div>
                <?php
                // echo $content->id;
                if(isset($_POST["submit"])) {
                    //API Url
                   $_POST['konten'] = rawurlencode($_POST['konten']);
                    //$url = 'http://nbp-backend.mybluemix.net/api/contents';
                    // if($content->services == "ContentOnDemand"){
                        // $url = 'http://nbp-backend.mybluemix.net/api/services/addContentCOD?id='.$content->service_id.'&content='.$_POST['konten'];
                    // }
                    // else{
                   $url = 'http://nbp-backend.mybluemix.net/api/services/addContentSub?id='.$services->id.'&content='.$_POST['konten'];
                    // }

                    //Initiate cURL.
                   $ch = curl_init($url);
                    //The JSON data.
                   $jsonData = array(
                    'content' => $_POST["konten"],
                    'date' => "2016-02-09",
                    'service_id' => $services->id,
                    'index' => 0
                    );

                    // foreach ($jsonData as $result) {
                    //     echo $result; 
                    //     echo "<br>";
                    // }

                    //Encode the array into JSON.
                   $jsonDataEncoded = json_encode($jsonData);

                    //Tell cURL that we want to send a POST request.
                   curl_setopt($ch, CURLOPT_POST, 1);

                    //Attach our encoded JSON string to the POST fields.
                   curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonDataEncoded);

                    //Set the content type to application/json
                   curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
                    //curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                    //Execute the request
                   $result = curl_exec($ch);
                    //header('Location: '.url('/services'));
                    //exit; 
               }
               ?>
               <!-- /.row -->

           </div>
           <!-- /.container-fluid -->

       </div>
       <!-- /#page-wrapper -->

   </div>
   <!-- /#wrapper -->
   @include('layouts/footer');
   <script>
    $("#field-subs-type").hide();
    $("#time-field").hide();
    $("#hit-field").hide();
    $("#service-type").change(function()
    {
        if($("#service-type").val() == "Content on Demand")
        {
            $("#field-subs-type").hide();
            $("#time-field").hide();
            $("#hit-field").hide();
        }
        else
        {
            $("#field-subs-type").show();
            $("#time-field").show();
            $("#subs-type").change(function(){
                if($("#subs-type").val() == "Time Based"){
                    $("#time-field").show();
                    $("#hit-field").hide();
                }
                else{
                    $("#time-field").hide();
                    $("#hit-field").show();
                }
            })
        }
    });
</script>
</body>

</html>
