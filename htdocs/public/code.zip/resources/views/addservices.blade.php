@include('layouts/header');
<body>
    <div id="wrapper">
        @include('layouts/navbar');
        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Add Services
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href=<?php echo url('/dashboard'); ?>>Dashboard</a>
                            </li>
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href=<?php echo url('/services'); ?>>Services Management</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-edit"></i> Add Services
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->

                <div class="row">
                    <div class="col-lg-12">
                        <form id="add-services" method="post" role="form" enctype='application/json'>
                            <div class="form-group">
                                <label>Keyword</label>
                                <input class="form-control" name="id" placeholder="" required="" autofocus="">
                        </div>
                            <div class="form-group">
                                <label>Select Service Type</label>
                                <select id="service-type" name="service-type" class="form-control" required>
                                    <option value="Content on Demand">Content on Demand</option>
                                    <option value="Subscription">Subscription</option>
                                </select>
                            </div>
                            <div id="field-subs-type" class="form-group">
                                <label>Select Subscription Type</label>
                                <select id="subs-type" name="subs-type" class="form-control">
                                    <option value="Time Based">Time Based</option>
                                    <option value="Hit Limit">Hit Limit</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Price</label>
                                <input class="form-control" name="price" placeholder="3000" required>
                            </div>
                            <div id="field-content" class="form-group">
                                <label>Konten</label>
                                <input class="form-control" name="content" placeholder="Isi kontenmu disini">
                            </div>
                            <div id="subs-time-field" class="form-group">
                                <label>Subscription Time</label>
                                <input class="form-control" name="subs-time" placeholder="7">
                            </div>
                            <div id="hit-limit-field" class="form-group">
                                <label>Hit Limit</label>
                                <input class="form-control" name="subs-hit-limit" placeholder="">
                            </div>
                            <div id="hit-limit-time-field" class="form-group">
                                <label>Hit Interval</label>
                                <input class="form-control" name="subs-hit-time" placeholder="">
                            </div>
                            <div id="hit-limit-time-type-field" class="form-group">
                                <label>Select Hit Interval Type</label>
                                <select id="hit-limit-time-type" name="hit-limit-time-type" class="form-control">
                                    <option value="Day">Day</option>
                                    <option value="Minutes">Minutes</option>
                                    <option value="Hours">Hours</option>
                                    <option value="Months">Months</option>
                                </select>
                            </div>
                            <div id="subs-period-hit-field" class="form-group">
                                <label>Subs Period Hit</label>
                                <input class="form-control" name="subs-period-hit" placeholder="">
                            </div>
                            {{ csrf_field() }}
                            <button type="submit" name="submit" class="btn btn-default">Submit Button</button>
                            <button type="reset" class="btn btn-default">Reset Button</button>
                        </form>
                    </div>
                </div>
                <?php
                if(isset($_POST["submit"])) {
                    //API Url
                    $url = 'http://nbp-backend.mybluemix.net/api/services/createService';
                    //Initiate cURL.
                    $ch = curl_init($url);
                    //The JSON data.
                    if($_POST["service-type"] == "Content on Demand"){
                        $jsonData = array(
                            'cp_admin' => 'berkah123',
                            'services' => 'ContentOnDemand',
                            'cod_content_date' => '2016-02-10',
                            'cod_content' => $_POST["content"],
                            'price' => $_POST["price"],
                            'keyword' => $_POST["id"],
                            'id' => str_replace(' ', '', $_POST["id"].$_POST["price"])
                            );
                    }
                    else{
                        if($_POST["subs-type"] == "Time Based"){
                            $jsonData = array(
                                'cp_admin' => 'berkah123',
                                'hitlimit' => $_POST["subs-hit-limit"],
                                'id' => str_replace(' ', '', $_POST["id"].$_POST["price"]),
                                'keyword' => $_POST["id"],
                                'price' => $_POST["price"],
                                'services' => 'Subscription',
                                'sub_period_day' => $_POST["subs-time"],
                                'sub_based' => 'Time',
                                'index_push' => 0,
                                'index_add' => 0,
                                'hitlimittime' => $_POST["subs-hit-time"],
                                "hitlimittimetype" => $_POST["hit-limit-time-type"]
                                );
                        }
                        else{
                            $jsonData = array(
                                'cp_admin' => 'berkah123',
                                'hitlimit' => $_POST["subs-hit-limit"],
                                'id' => str_replace(' ', '', $_POST["id"].$_POST["price"]),
                                'keyword' => $_POST["id"],
                                'price' => $_POST["price"],
                                'services' => 'Subscription',
                                'sub_based' => 'Hit',
                                'sub_period_hit' => $_POST["subs-period-hit"],
                                'index_push' => 0,
                                'index_add' => 0,
                                'hitlimittime' => $_POST["subs-hit-time"],
                                "hitlimittimetype" => $_POST["hit-limit-time-type"]
                                );
                        }
                    }
                    // foreach ($jsonData as $result) {
                    //     echo $result; 
                    //     echo "<br>";
                    // }
                    //Encode the array into JSON.
                    $jsonDataEncoded = json_encode($jsonData);
                    //Tell cURL that we want to send a POST request.
                    curl_setopt($ch, CURLOPT_POST, 1);
                    //Attach our encoded JSON string to the POST fields.
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonDataEncoded);
                    //Set the content type to application/json
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); 
                    //curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                    //Execute the request
                    $result = curl_exec($ch);
                    //header('Location: '.url('/services'));
                    //exit;
                }
                ?>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
    @include('layouts/footer');
    <script>
        $("#field-subs-type").hide();
        $("#subs-time-field").hide();
        $("#hit-limit-field").hide();
        $("#hit-limit-time-field").hide();
        $("#subs-period-hit-field").hide();
        $("#hit-limit-time-type-field").hide();
        $("#service-type").change(function()
        {
            if($("#service-type").val() == "Content on Demand")
            {
                $("#field-subs-type").hide();
                $("#subs-time-field").hide();
                $("#hit-limit-field").hide();
                $("#hit-limit-time-field").hide();
                $("#subs-period-hit-field").hide();
                $("#hit-limit-time-type-field").hide();
                $("#field-content").show();
            }
            else
            {
                $("#field-content").hide();
                $("#field-subs-type").show();
                $("#subs-time-field").show();
                $("#hit-limit-field").show();
                $("#hit-limit-time-field").show();
                $("#hit-limit-time-type-field").show();
                // $("#subs-type").change(function(){
                //     if($("#subs-type").val() == "Time Based"){
                //         $("#time-field").show();
                //         $("#hit-limit-field").hide();
                //     }
                //     else{
                //         $("#time-field").hide();
                //         $("#hit-limit-field").show();
                //     }
                // })
}
});
</script>
</body>

</html>
