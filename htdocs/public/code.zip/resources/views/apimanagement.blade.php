@include('layouts/header');
<body>
    <div id="wrapper">
        @include('layouts/navbar');
        <div id="page-wrapper">

            <div class="container-fluid">
                <iframe src="http://nbp-strongloop.mybluemix.net/explorer/" width="100%" height="500px"></iframe>
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    @include('layouts/footer');
</body>

</html>
