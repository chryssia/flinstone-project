@include('layouts/header');
<body>
    <div id="wrapper">
        @include('layouts/navbar');
        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Code Management
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href=<?php echo url('/dashboard'); ?>>Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-edit"></i> Code Management
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->
                <!-- row start -->
                <div class="row">
                    <div class="col-lg-12">
                        <h3>Download your code here</h3>
                        <a href="http://example.com/files/myfile.pdf" type="button" class="btn btn-info" target="_blank">Download</a>
                    </div>
                </div>
                <!-- /row -->
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    @include('layouts/footer');
</body>

</html>
