@include('layouts/header');
<body>
    <div id="wrapper">
        @include('layouts/navbar');
        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Edit Services
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href=<?php echo url('/dashboard'); ?>>Dashboard</a>
                            </li>
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href=<?php echo url('/services'); ?>>Services Management</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-edit"></i> Add Services
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->

                <div class="row">
                    <div class="col-lg-12">
                        <form id="add-services" method="post" role="form" enctype='application/json'>
                            <div class="form-group">
                                <label>Keyword</label>
                                <input class="form-control" readonly name="id" placeholder="" value={{$data->keyword}} required="" autofocus="">
                            </div>
                            <div class="form-group">
                                <label>Price</label>
                                <input class="form-control" name="price" value='{{$data->price}}' required>
                            </div>
                            <div id="field-content" class="form-group">
                                <label>Konten</label>
                                <input class="form-control" name="content" value='{{$data->cod_content}}' required>
                            </div>
                            {{ csrf_field() }}
                            <button type="submit" name="submit" class="btn btn-default">Submit Button</button>
                            <button type="reset" class="btn btn-default">Reset Button</button>
                        </form>
                    </div>
                </div>
                <?php
                if(isset($_POST["submit"])) {
                    //API Url
                    $url = 'http://nbp-backend.mybluemix.net/api/services/createService';
                    //Initiate cURL.
                    $ch = curl_init($url);
                    //The JSON data.
                    $jsonData = array(
                        'cp_admin' => 'berkah123',
                        'services' => 'ContentOnDemand',
                        'cod_content_date' => '2016-02-10',
                        'cod_content' => $_POST["content"],
                        'price' => $_POST["price"],
                        'keyword' => $_POST["id"],
                        'id' => str_replace(' ', '', $_POST["id"].$_POST["price"])
                        );
                    // foreach ($jsonData as $result) {
                    //     echo $result; 
                    //     echo "<br>";
                    // }
                    //Encode the array into JSON.
                    $jsonDataEncoded = json_encode($jsonData);
                    //Tell cURL that we want to send a POST request.
                    curl_setopt($ch, CURLOPT_POST, 1);
                    //Attach our encoded JSON string to the POST fields.
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonDataEncoded);
                    //Set the content type to application/json
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); 
                    //curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                    //Execute the request
                    $result = curl_exec($ch);
                    //header('Location: '.url('/services'));
                    //exit;
                }
                ?>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
    @include('layouts/footer');
</body>

</html>
