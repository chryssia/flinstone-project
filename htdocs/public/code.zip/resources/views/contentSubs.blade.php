@include('layouts/header');
<body>
    <div id="wrapper">
        @include('layouts/navbar');
        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Content Management
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href=<?php echo url('/dashboard'); ?>>Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-edit"></i> <a href=<?php echo url('/services'); ?>>Service Management</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-edit"></i> Content Management
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="col-lg-12">
                        <a class="btn btn-success" href=<?php echo "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]".'/add'; ?> type="submit">Add Content</a>
                    </div>
                </div>
            </br>
            <div class="row">
                <div class="col-lg-12">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover table-striped">
                            <thead>
                                <tr>
                                    <th>Nomor</th>
                                    <th>Service</th>
                                    <th>Date Created</th>
                                    <th>Push Schedule</th>
                                    <th>Push Status</th>
                                    <th>Content</th>
                                    <th>Options</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1; ?>
                                @foreach($data as $key => $content)
                                
                                <tr>
                                    <td>{{$i}}</td>
                                    <td>{{$content->service_id}}</td>
                                    <td>{{$content->date_created}}</td>
                                    <td>{{$content->date_push}}</td>
                                    <td>{{$content->push_status}}</td>
                                    <td>{{$content->content}}</td>
                                    <td>
                                        <a href=<?php echo url('/content/subs/edit',$content->id); ?> class="btn btn-default">Edit Content</a>
                                        <form role="form" method="delete">
                                            <input type="hidden" name="id" value=<?php echo $content->id?>>
                                            <button type="submit" class="btn btn-default" name="delete" value="DELETE">Delete Content</button>
                                            {{ csrf_field() }}
                                        </form>
                                    </td>
                                </tr>
                                <?php $i++; ?>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- /.row -->
            <?php
            if(isset($_REQUEST["id"])){
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, "http://nbp-backend.mybluemix.net/api/contents/$_REQUEST[id]");
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        // execute the request
                $output = curl_exec($ch);
                $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        // close curl resource to free up system resources
                curl_close($ch);
                header('Location: '.url('/content/subs/'.$content->service_id));
                exit;
            }
            ?>

        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- /#page-wrapper -->
</div>
<!-- /#wrapper -->
@include('layouts/footer');
</body>

</html>
