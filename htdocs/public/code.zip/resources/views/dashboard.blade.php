@include('layouts/header')
<body>
    <div id="wrapper">
        @include('layouts/navbar')

        <div id="page-wrapper">
            <div class="container-fluid">
                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Welcome in Telkomsel CP Management Systems
                        </h1>
                        <ol class="breadcrumb">
                            <li class="active">
                                <i class="fa fa-dashboard"></i> Dashboard
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->
                @include('layouts/TwitterAPIExchange')
                <div class="row">
                    <?php
                    $settings = array(
                        'oauth_access_token' => "83343148-xc4oNQ8P5HrRHzmvW47gOb4VXfXOEHcvMZ4OjCtni",
                        'oauth_access_token_secret' => "h8mQx3BX3JiCywVF4Z1hzOAEBggH9T1hp60xTjoYpU6yX",
                        'consumer_key' => "KM5oQBpL3wAduUsJbdJ0pPXUl",
                        'consumer_secret' => "aHDTgjRwXKNrdNnyuMHsUJnJL8R9cLzkU1fH8UIQZHYf4cPQiz"
                        );
                    $url = 'https://api.twitter.com/1.1/trends/place.json';
                    $getfield = '?id=1047378';
                    $requestMethod = 'GET';                
                    $twitter = new TwitterAPIExchange($settings);
                    $trending = $twitter->setGetfield($getfield)->buildOauth($url, $requestMethod)->performRequest();
                    $trending = json_decode($trending);
                    ?>

                </div>
                <!-- <div class="row">
                    <div class="col-lg-12">
                        <div class="alert alert-info alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-info-circle"></i>You have {{count($custData)}} customers right now
                        </div>
                    </div>
                </div> -->
                <!-- /.row -->

                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-comments fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">{{count($custData)}}</div>
                                        <div>New Subscribers!</div>
                                    </div>
                                </div>
                            </div>
                            <!-- Button trigger modal -->
                            <a href="#" data-toggle="modal" data-target="#myModal">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <!-- <div id="id01"></div> -->
                    <!-- Modal -->
                    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title" id="myModalLabel">MSISDN List</h4>
                                </div>
                                <div class="modal-body">
                                    @foreach($custData as $key => $data)
                                    <p>{{$data->id}}</p>
                                    @endforeach
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    <button type="button" class="btn btn-primary">Save changes</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="panel panel-green">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-tasks fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">{{count($contentsData)}}</div>
                                        <div>Content</div>
                                    </div>
                                </div>
                            </div>
                            <a href=<?php echo url('/contents') ?>>
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="panel panel-yellow">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-shopping-cart fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">{{count($servicesData)}}</div>
                                        <div>Services</div>
                                    </div>
                                </div>
                            </div>
                            <a href=<?php echo url('/services'); ?>>
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <!-- /.row -->

                <div class="row">
                    <div class="col-lg-4">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-bar-chart-o fa-fw"></i> Revenue Report</h3>
                            </div>
                            <div class="panel-body">
                                <!-- <div id="morris-area-chart"></div> -->
                                <canvas id="myChart" width="400px" height="300px"></canvas>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-bar-chart-o fa-fw"></i> Twitter Search</h3>
                            </div>
                            <div class="panel-body">
                                <form id="add-services" method="get" role="form" class="form-inline" enctype='application/json'>
                                    <div id="search-box" class="form-group">
                                        <label>Twitter Insight Search</label>
                                        <input class="form-control" name="search" placeholder="Search topic" required>
                                        <input class="form-control" name="number" placeholder="Number of tweets (max: 500)" required>                                        
                                    </div>
                                    {{ csrf_field() }}
                                    <button type="submit" name="submit" class="btn btn-default">Submit Button</button>
                                </form>
                                <?php
                                if(isset($_GET["submit"])) {
                                    //API Url
                                    $json = file_get_contents("https://29113284-5b82-4a47-ba1c-03f12fcdd310:iLCvyizLwQ@cdeservice.mybluemix.net:443/api/v1/messages/search?q=$_GET[search]&size=$_GET[number]");
                                    $data = json_decode($json);
                                    echo '<h4>'.$data->search->results.' data founded for '.$_GET['search'].' in twitter</h4>';
                                    // echo '<div class="alert alert-info alert-dismissable">';
                                    // echo '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>';
                                    // echo '<i class="fa fa-info-circle"></i> '.$data->search->results.' search results for '.$_GET['search'].' founded in twitter';
                                    // echo '</div>';
                                    $male = 0;$female=0;$unknownGender=0;
                                    $temp = array();
                                    $countryList = array();
                                    foreach ($data->tweets as $key => $value) {
                                        if(isset($value->cde->author->gender)){
                                            if($value->cde->author->gender == "male"){
                                                $male++;
                                            }
                                            elseif ($value->cde->author->gender == "female") {
                                                $female++;
                                            }
                                            else{
                                                $unknownGender++;
                                            }
                                        }
                                        if(isset($value->cde->author->location->country)){
                                            $temp[]=$value->cde->author->location->country;
                                            if(!in_array($value->cde->author->location->country, $countryList) && $value->cde->author->location->country!=""){
                                                $countryList[]=$value->cde->author->location->country;
                                            }
                                        }
                                    }?>

                                    <h4>Statistics from <?php echo $_GET['number']; ?> tweets analyzed </h4>
                                    <div class="col-lg-6">
                                        <li>Male: <?php echo $male;?></li>
                                        <li>Female: <?php echo $female;?></li>
                                        <li>Unknown Gender: <?php echo $unknownGender;?></li>
                                    </div>
                                    <div class="col-lg-6">
                                        <?php
                                        function array_count_values_of($value, $array) {
                                            $counts = array_count_values($array);
                                            return $counts[$value];
                                        }
                                        foreach ($countryList as $key => $value) {
                                            echo '<li>'.$value.' - '.array_count_values_of($value,$temp).'</li>';
                                        }
                                    echo '</div>';
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->

                <div class="row">
                    <div class="col-lg-4">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-long-arrow-right fa-fw"></i> Topic Inspiration for Contents</h3>
                            </div>
                            <div class="panel-body">
                                <ol>
                                    <?php $i=0; ?>
                                    @foreach($trending[0]->trends as $key => $data)
                                    <li><a href={{$data->url}} >{{$data->name}}</a></li>
                                    <?php $i++;if($i>=10){break;} ?>
                                    @endforeach

                                </ol>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-clock-o fa-fw"></i> History Panel</h3>
                            </div>
                            <div class="panel-body">
                                <div class="list-group">
                                    <a href="#" class="list-group-item">
                                        <span class="badge">4 minutes ago</span>
                                        <i class="fa fa-fw fa-comment"></i> Created New Content
                                    </a>
                                    <a href="#" class="list-group-item">
                                        <span class="badge">20 minutes ago</span>
                                        <i class="fa fa-fw fa-comment"></i> Created New Services
                                    </a>
                                    <a href="#" class="list-group-item">
                                        <span class="badge">1 hour ago</span>
                                        <i class="fa fa-fw fa-comment"></i> New Subscriber +6217281232
                                    </a>
                                </div>
                                <div class="text-right">
                                    <a href="#">View All Activity <i class="fa fa-arrow-circle-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-long-arrow-right fa-fw"></i> Most Hot Services</h3>
                            </div>
                            <div class="panel-body">
                                <ol>
                                    <li>AFGAN: 2 Subscribers</li>
                                    <li>SYAHRINI: 0 Subscribers</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    @include('layouts/footer')
</body>

</html>
