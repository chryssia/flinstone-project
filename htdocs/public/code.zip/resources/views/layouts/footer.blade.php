    <!-- jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

    <!-- Chart JS JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/1.0.2/Chart.min.js"></script>
    <script src={{ asset('assets/js/chart-data.js') }}></script>

    <script type="text/javascript">
    	$.ajaxSetup({
    		headers: { 'X-CSRF-Token' : $('meta[name=_token]').attr('content') }
    	});
    </script>