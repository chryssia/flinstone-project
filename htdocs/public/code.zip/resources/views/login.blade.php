@include('layouts/header');
<style>
  body{
    background-color:#eee !important;
  }
</style>
<body>
  <div class="container">
    <div class="row">
      <div class="col">
        <img src="http://cdn.utekno.com/wp-content/uploads/2015/02/telkomsel-logo.png" width="50%">
      </div>
    </div>
    <form class="form-signin" method="post" role="form" enctype='application/json'>
    <label for="username" class="sr-only">Username</label>
      <input type="text" id="username" name="username" class="form-control" placeholder="Username" required="" autofocus="">
      <label for="password" class="sr-only">Password</label>
      <input type="password" id="password" name="password" class="form-control" placeholder="Password" required="">
      <div class="checkbox">
        <label>
          <input type="checkbox" value="remember-me"> Remember me
        </label>
      </div>
      {{ csrf_field() }}
      <button type="submit" name="submit" class="btn btn-lg btn-primary btn-block">Sign in</button>
    </form>
    <?php
    if(isset($_POST["submit"])) {
                                    //API Url
      $url = 'http://nbp-backend.mybluemix.net/api/admins/login';
                //Initiate cURL.
      $ch = curl_init($url);
                //The JSON data.
      $jsonData = array(
        'cp_id' => $_POST["username"],
        'cp_password' => $_POST["password"]
        );
                    // foreach ($jsonData as $result) {
                    //     echo $result; 
                    //     echo "<br>";
                    // }

                //Encode the array into JSON.
      $jsonDataEncoded = json_encode($jsonData);

                //Tell cURL that we want to send a POST request.
      curl_setopt($ch, CURLOPT_POST, 1);

                //Attach our encoded JSON string to the POST fields.
      curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonDataEncoded);

                //Set the content type to application/json
      curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); 

      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

                //Execute the request
      $result = curl_exec($ch);
      // echo $result;
      $result = json_decode($result);
      if($result->loginStatus==1){
        header('Location: '.url('/dashboard'));
        exit;
      }
      else{
        echo 'salah';
      }
    }
    ?>
  </div>
  @include('layouts/footer');
</body>

</html>

