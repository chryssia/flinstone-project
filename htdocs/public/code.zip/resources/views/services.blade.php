@include('layouts/header');
<body>
    <div id="wrapper">
        @include('layouts/navbar');
        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Service Management
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href=<?php echo url('/dashboard'); ?>>Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-edit"></i> Service Management
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="col-lg-12">
                        <a class="btn btn-success" href=<?php echo url('/services/add'); ?> type="submit">Add Services</a>
                    </div>
                </div>
            </br>
            <div class="row">
                <div class="col-lg-12">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover table-striped">
                            <thead>
                                <tr>
                                    <th>Service Name</th>
                                    <th>Keyword</th>
                                    <th>Service Type</th>
                                    <th>MSISDN</th>
                                    <th>Options</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($data as $key => $services)
                                <tr>
                                    <td>{{$services->keyword}}</td>
                                    <td>{{$services->keyword}}</td>
                                    <td>{{$services->services}}</td>
                                    <td>
                                        <?php if(isset($services->MSISDN)){
                                            foreach ($services->MSISDN as $key => $value) {
                                                echo '<p>'.$value.'</p>';
                                            }
                                        }?>
                                    </td>
                                    <td>
                                        <?php if($services->services == "ContentOnDemand"){
                                            echo '<a href="'.url('/content/cod',$services->id).'" class="btn btn-default">Edit Content</a>';
                                        }else{
                                            echo '<a href="'.url('/content/subs',$services->id).'" class="btn btn-default">View Content</a>';
                                        } ?>
                                        
                                        <form role="form" method="delete">
                                            <input type="hidden" name="id" value=<?php echo $services->id ?>>
                                            <button type="submit" class="btn btn-default" name="delete" value="DELETE">Delete Services</button>
                                            {{ csrf_field() }}
                                        </form>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
                <?php
                if(isset($_REQUEST["id"])){
                    $ch = curl_init();
                // curl_setopt($ch, CURLOPT_URL, "http://nbp-backend.mybluemix.net/api/contentproviders/$_REQUEST[id]");
                    curl_setopt($ch, CURLOPT_URL, "http://nbp-backend.mybluemix.net/api/services/deleteServiceandContent?id=$_REQUEST[id]");

                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        // execute the request
                    $output = curl_exec($ch);
                    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        // close curl resource to free up system resources
                    curl_close($ch);
                    header('Location: '.url('/services'));
                    exit;
                }
                ?>


            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    @include('layouts/footer');
</body>

</html>
