@include('layouts/header');
<body>
    <div id="wrapper">
        @include('layouts/navbar');
        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Transaction History
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href=<?php echo url('/dashboard'); ?>>Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-edit"></i> Transaction History
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->
            </br>
            <div class="row">
                <div class="col-lg-12">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover table-striped">
                            <thead>
                                <tr>
                                    <th>Nomor</th>
                                    <th>MSISDN</th>
                                    <th>Date</th>
                                    <th>Price</th>
                                    <th>Service ID</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $i = 1; ?>
                                @foreach($data as $key => $transaction)
                                <tr>
                                    <td>{{$i}}</td>
                                    <td>{{$transaction->MSISDN}}</td>
                                    <td>{{$transaction->date}}</td>
                                    <td>{{$transaction->price}}</td>
                                    <td>{{$transaction->service_id}}</td>
                                </tr>
                                <?php $i++; ?>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- /.row -->
            <?php
            if(isset($_REQUEST["id"])){
                $ch = curl_init();
                // curl_setopt($ch, CURLOPT_URL, "http://nbp-backend.mybluemix.net/api/contentproviders/$_REQUEST[id]");
                curl_setopt($ch, CURLOPT_URL, "http://nbp-backend.mybluemix.net/api/services/deleteServiceandContent?id=$_REQUEST[id]");

                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        // execute the request
                $output = curl_exec($ch);
                $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        // close curl resource to free up system resources
                curl_close($ch);
                header('Location: '.url('/services'));
                exit;
            }
            ?>


        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- /#page-wrapper -->
</div>
<!-- /#wrapper -->
@include('layouts/footer');
</body>

</html>
